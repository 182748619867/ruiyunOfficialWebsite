<template>
    <div class="foot-home">
        <div class="foot-top"></div>
        <div class="foot-body">
            <div class="row">123sa</div>
        </div>
    </div>
</template>

<script>
export default {
    
}
</script>


<style scoped>
    
</style>