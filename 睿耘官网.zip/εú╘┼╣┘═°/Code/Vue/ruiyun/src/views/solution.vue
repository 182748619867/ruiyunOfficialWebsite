<template>
    <div>
        <div class="page-title">
            <div class="container">
                我是 解决方案
            </div>
        </div>
    </div>
</template>


<script>
export default {
    
}
</script>


<style scoped>

</style>