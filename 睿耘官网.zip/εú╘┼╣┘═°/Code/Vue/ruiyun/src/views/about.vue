<template>
    <div>
        <div class="page-title">
            <div class="container">
                关于睿耘 模块
            </div>
        </div>
    </div>
</template>


<script>
export default {
    
}
</script>


<style scoped>

</style>