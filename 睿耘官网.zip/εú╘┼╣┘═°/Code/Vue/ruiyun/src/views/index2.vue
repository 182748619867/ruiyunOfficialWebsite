<template>
    <div>
        index2
        <div @click="$router.go(-1)">回退</div>
    </div>
</template>
<script>
export default {
    methods: {
        
    },
}
</script>